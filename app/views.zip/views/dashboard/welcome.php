<section class="content invoice">
    <div class="row">
        <div class="col-md-12">
            Dashboard content is updating
           
                
        </div>
    </div>
</section>

<br><br>
