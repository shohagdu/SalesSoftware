<div class="form-group has-feedback">

    <label>Due Amount</label>
    <input name="hdndueamount" id="myid3" value="<?php echo $results['dueAmount']?>" readonly class="form-control" placeholder="Due Amount">
    <input type="hidden" name="purchaseid" value="<?php echo $results['purchaseNo']?>" readonly class="form-control" placeholder="Due Amount">
</div>